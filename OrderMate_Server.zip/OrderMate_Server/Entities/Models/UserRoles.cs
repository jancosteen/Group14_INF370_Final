﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Models
{
    public class UserRoles
    {
        public string UserId { get; set; }
        public string Username { get; set; }
        public bool selected { get; set; }
    }
}
