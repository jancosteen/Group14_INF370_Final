﻿using System;

namespace Entities.Models
{
    internal class requiredAttribute : Attribute
    {
    }
}