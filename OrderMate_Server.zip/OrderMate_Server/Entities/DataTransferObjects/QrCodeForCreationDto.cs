﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class QrCodeForCreationDto
    {
        public int? RestaurantIdFk { get; set; }
    }
}
