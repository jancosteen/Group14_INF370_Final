﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ReservationStatusDto
    {
        public int ReservationStatusId { get; set; }
        public string ReservationStatus1 { get; set; }
    }
}
