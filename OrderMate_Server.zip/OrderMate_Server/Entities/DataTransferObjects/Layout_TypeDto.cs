﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class Layout_TypeDto
    {
        public int LayoutTypeId { get; set; }
        public string LayoutType1 { get; set; }
    }
}
