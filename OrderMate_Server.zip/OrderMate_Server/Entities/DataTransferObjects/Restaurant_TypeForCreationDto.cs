﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class Restaurant_TypeForCreationDto
    {
        public string RestaurantType1 { get; set; }

    }
}
