﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ProductReorderFreqForUpdateDto
    {
        public string ProductReorderFreq1 { get; set; }
    }
}
