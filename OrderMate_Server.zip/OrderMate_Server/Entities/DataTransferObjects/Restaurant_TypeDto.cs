﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class Restaurant_TypeDto
    {
        public int RestaurantTypeId { get; set; }
        public string RestaurantType1 { get; set; }
    }
}
