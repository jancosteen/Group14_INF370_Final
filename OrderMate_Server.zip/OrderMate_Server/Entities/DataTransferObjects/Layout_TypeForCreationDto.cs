﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class Layout_TypeForCreationDto
    {
        public string LayoutType1 { get; set; }

    }
}
