﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class UserRoleDto
    {
        public int UserRoleId { get; set; }
        public string UserRole1 { get; set; }
    }
}
