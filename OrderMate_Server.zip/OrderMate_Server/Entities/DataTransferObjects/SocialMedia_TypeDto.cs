﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class SocialMedia_TypeDto
    {
        public int SocialMediaTypeId { get; set; }
        public string SocialMediaType1 { get; set; }
    }
}
