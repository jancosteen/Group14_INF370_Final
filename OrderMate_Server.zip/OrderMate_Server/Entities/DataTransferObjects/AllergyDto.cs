﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class AllergyDto
    {
        public int AllergyId { get; set; }
        public string Allergy1 { get; set; }
    }
}
