﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class WrittenOffStockForUpdateDto
    {
    
        public DateTime WrittenOfStockDate { get; set; }
        
    }
}
