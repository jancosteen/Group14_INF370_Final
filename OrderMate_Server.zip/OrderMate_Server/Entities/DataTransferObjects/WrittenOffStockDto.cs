﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class WrittenOffStockDto
    {
        public int WrittenOfStockId { get; set; }
        public DateTime WrittenOfStockDate { get; set; }
        
    }
}
