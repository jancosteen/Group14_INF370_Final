﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class MenuItemCategoryForUpdateDto
    {
        public string MenuItemCategory1 { get; set; }

    }
}
