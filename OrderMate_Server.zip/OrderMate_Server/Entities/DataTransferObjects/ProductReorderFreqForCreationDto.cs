﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ProductReorderFreqForCreationDto
    {
        public string ProductReorderFreq1 { get; set; }
    }
}
