﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ReservationStatusForUpdateDto
    {
        public string ReservationStatus1 { get; set; }
    }
}
