﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ProductStockTakeForUpdateDto
    {
        public int ProductStockTakeQty { get; set; }
    }
}
