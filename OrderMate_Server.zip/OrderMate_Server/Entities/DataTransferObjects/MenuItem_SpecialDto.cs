﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class MenuItem_SpecialDto
    {
        public int SpecialIdFk { get; set; }
        public int MenuItemIdFk { get; set; }

    }
}
