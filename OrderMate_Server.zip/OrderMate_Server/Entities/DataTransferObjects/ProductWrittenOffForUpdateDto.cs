﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ProductWrittenOffForUpdateDto
    { 
        public int WrittenOffQty { get; set; }
        
    }
}
