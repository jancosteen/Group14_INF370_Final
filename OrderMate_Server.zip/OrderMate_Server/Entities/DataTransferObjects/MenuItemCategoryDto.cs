﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class MenuItemCategoryDto
    {
        public int MenuItemCategoryId { get; set; }
        public string MenuItemCategory1 { get; set; }

    }
}
