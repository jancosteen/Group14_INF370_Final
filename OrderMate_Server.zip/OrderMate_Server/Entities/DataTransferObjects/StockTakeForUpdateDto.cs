﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class StockTakeForUpdateDto
    {
        public DateTime StockTakeDate { get; set; }
    }
}
