﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class SocialMedia_TypeForUpdateDto
    {
        public string SocialMediaType1 { get; set; }

    }
}
