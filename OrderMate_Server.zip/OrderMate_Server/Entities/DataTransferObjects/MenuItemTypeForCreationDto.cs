﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class MenuItemTypeForCreationDto
    {
        public string MenuItemType1 { get; set; }

    }
}
