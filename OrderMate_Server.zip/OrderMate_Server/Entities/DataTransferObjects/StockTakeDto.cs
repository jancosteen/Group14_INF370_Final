﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class StockTakeDto
    {
        public int StockTakeId { get; set; }
        public DateTime StockTakeDate { get; set; }
    }
}
