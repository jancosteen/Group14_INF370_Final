﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ShiftStatusDto
    {
        public int ShiftStatusId { get; set; }
        public string ShiftStatus1 { get; set; }
    }
}
