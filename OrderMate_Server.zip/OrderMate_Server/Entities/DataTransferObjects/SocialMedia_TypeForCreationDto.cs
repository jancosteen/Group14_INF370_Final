﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class SocialMedia_TypeForCreationDto
    {
        public string SocialMediaType1 { get; set; }

    }
}
