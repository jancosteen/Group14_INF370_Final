﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ProductTypeForUpdateDto
    {
        public string ProductType1 { get; set; }
    }
}
