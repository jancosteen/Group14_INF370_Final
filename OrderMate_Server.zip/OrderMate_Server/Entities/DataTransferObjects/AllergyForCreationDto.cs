﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class AllergyForCreationDto
    { 
        public string Allergy1 { get; set; }
    }
}
