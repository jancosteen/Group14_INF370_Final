﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ReservationStatusForCreationDto
    {
        public string ReservationStatus1 { get; set; }
    }
}
