﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ShiftStatusForCreationDto
    {
        public string ShiftStatus1 { get; set; }
    }
}
