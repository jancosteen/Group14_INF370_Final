﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class MenuItemTypeDto
    {
        public int MenuItemTypeId { get; set; }
        public string MenuItemType1 { get; set; }
    }
}
