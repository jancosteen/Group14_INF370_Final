﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ReservationForCreationDto
    {
        public DateTime ReservationDateCreated { get; set; }
        public DateTime ReservationDateReserved { get; set; }
        public int ReservationPartyQty { get; set; }
        public int? UserIdFk { get; set; }
        public int? ReservationStatusIdFk { get; set; }
    }
}
