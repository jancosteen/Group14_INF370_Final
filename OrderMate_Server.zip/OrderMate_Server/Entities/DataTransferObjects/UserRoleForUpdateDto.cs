﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class UserRoleForUpdateDto
    {
        public string UserRole1 { get; set; }
    }
}
