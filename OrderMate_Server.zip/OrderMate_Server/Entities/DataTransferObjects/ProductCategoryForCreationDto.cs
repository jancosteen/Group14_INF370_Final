﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class ProductCategoryForCreationDto
    {
        public string ProductCategory1 { get; set; }
    }
}
