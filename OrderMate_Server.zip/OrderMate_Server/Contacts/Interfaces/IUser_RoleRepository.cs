﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Contacts.Interfaces
{
    public interface IUser_RoleRepository: IRepositoryBase<UserRole>
    {
        IEnumerable<UserRole> GetAllUserRoles();
        UserRole GetUserRoleById(string userRoleId);
        UserRole GetUserRoleWithDetails(string userRoleId);
        void CreateUserRole(UserRole userRole);
        void UpdateUserRole(UserRole userRole);
        void DeleteUserRole(UserRole userRole);
    }
}
