﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Contacts.Interfaces
{
    class IRegistration
    {
    }
}
