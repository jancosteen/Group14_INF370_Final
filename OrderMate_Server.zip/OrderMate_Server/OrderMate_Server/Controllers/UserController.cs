﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Contacts;
using Entities.DataTransferObjects;
using Entities.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.IdentityModel.Tokens;

namespace OrderMate_Server.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private ILoggerManager _logger;
        private IRepositoryWrapper _repository;
        private IMapper _mapper;

        public object Configuration { get; private set; }

        private UserManager<User> _userManager ;


        public UserController(ILoggerManager logger, IRepositoryWrapper repository, IMapper mapper, UserManager<User> userManager)
        {
            _logger = logger;
            _repository = repository;
            _mapper = mapper;
            _userManager = userManager;
        }

        
        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login(Login model)
        {
            try
            {
                var user = await _userManager.FindByNameAsync(model.Username);

                if (model == null)
                {
                    _logger.LogError($"user with username: {model.Username}, hasn't been found in db.");
                    return NotFound();
                }
                else
                {
                    var role = await _userManager.GetRolesAsync(user);
                    IdentityOptions ops = new IdentityOptions();

                    _logger.LogInfo($"Returned user with username: {model.Username}");
                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = new ClaimsIdentity(new Claim[] {
                            new Claim("UserID",user.Id.ToString()),
                            new Claim(ops.ClaimsIdentity.RoleClaimType,role.FirstOrDefault())

                        }),
                        Expires = DateTime.UtcNow.AddDays(1),
                        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes("1234567891234567")),SecurityAlgorithms.HmacSha256Signature)
                    };

                    var tokenHandler = new JwtSecurityTokenHandler();
                    var securityToken = tokenHandler.CreateToken(tokenDescriptor);
                    var token = tokenHandler.WriteToken(securityToken);
                    
                   
                  //  var userResult = _mapper.Map<UserDto>(user);
                    return Ok(new { token });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside GetUserById action: {ex.InnerException.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

    


        [HttpPost]
        [Route("Register")]
        public IActionResult PostUser(AccountModel model)
        {
            var user = new User()
            {
                UserName = model.Username,
                User_Name = model.User_Name,
                User_Surname = model.User_Surname,
                User_Contact_Number = model.User_Contact_Number,
                Email = model.Email,
                Password = model.Password,
                ConfirmPassword = model.ConfirmPassword
            };

            try
            {
                var userEntity = _mapper.Map<User>(user);

                _repository.User.CreateUser(userEntity);
                _repository.Save();

                var createdUser = _mapper.Map<UserDto>(userEntity);

                return CreatedAtRoute("UserById", new { id = createdUser.UserId }, createdUser);

              

                
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public IActionResult GetAllUsers()
        {
            try
            {
                var users = _repository.User.GetAllUsers();
                _logger.LogInfo($"Returned all users from db.");

                var usersResult = _mapper.Map<IEnumerable<UserDto>>(users);
                return Ok(usersResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went work inside the GetAllUsers action: {ex.InnerException.Message}");
                return StatusCode(500, "Internal server error");

            }
        }

        [HttpGet("{id}", Name = "UserById")]
        public IActionResult GetUserById(int id)
        {
            try
            {
                var user = _repository.User.GetUserById(id);

                if (user == null)
                {
                    _logger.LogError($"user with id: {id}, hasn't been found in db.");
                    return NotFound();
                }
                else
                {
                    _logger.LogInfo($"Returned user with id: {id}");

                    var userResult = _mapper.Map<UserDto>(user);
                    return Ok(userResult);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside GetUserById action: {ex.InnerException.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("{id}/detail")]
        public IActionResult GetUserWithDetails(int id)
        {
            try
            {
                var user = _repository.User.GetUserWithDetails(id);

                if (user == null)
                {
                    _logger.LogError($"user with id: {id}, hasn't been found in db.");
                    return NotFound();
                }
                else
                {
                    _logger.LogInfo($"user with details for id: {id}");

                    var userResult = _mapper.Map<UserDetailsDto>(user);
                    return Ok(userResult);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside GetUserWithDetails action: {ex.InnerException.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("Create")]
        public async Task<IActionResult> CreateUser( User user)
        {
            var appuser = new User()
            {
                UserName = user.UserName,
                Email = user.Email,
                User_Contact_Number = user.User_Contact_Number,
                PhoneNumber = user.User_Contact_Number,
                User_Name = user.User_Name,
                User_Surname = user.User_Surname,

            };
            try
            {

                
                if (user == null)
                {
                    _logger.LogError("user object sent from client is null.");
                    return BadRequest("user object is null");
                }
                if (!ModelState.IsValid)
                {
                    _logger.LogError("Invalid user object sent from client.");
                    return BadRequest("Invalid model object");
                }

                var result = await _userManager.CreateAsync(appuser, user.Password);
                await _userManager.AddToRoleAsync(appuser, user.UserRoleIdFk);
                return Ok(result);
               
                /*
                _repository.User.CreateUser(user);
                _repository.Save();

                var createdUser = _mapper.Map<User>(user);

                return CreatedAtRoute("UserById", new { id = createdUser.Id }, createdUser);
                */

            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside CreateUser action: {ex.InnerException.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdateUser(int id, [FromBody] UserForUpdateDto user)
        {
            try
            {
                if (user == null)
                {
                    _logger.LogError("user object sent from client is null.");
                    return BadRequest("user object is null");
                }
                if (!ModelState.IsValid)
                {
                    _logger.LogError("Invalid user object sent from client.");
                    return BadRequest("Invalid model object");
                }

                var userEntity = _repository.User.GetUserById(id);
                if (userEntity == null)
                {
                    _logger.LogError($"user with id: {id}, hasn't been found in db.");
                    return NotFound();
                }

                _mapper.Map(user, userEntity);

                _repository.User.UpdateUser(userEntity);
                _repository.Save();

                return NoContent();

            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside UpdateUser action: {ex.InnerException.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            try
            {
                var user = _repository.User.GetUserById(id);
                if (user == null)
                {
                    _logger.LogError($"user with id: {id}, hasn't been found in db.");
                    return NotFound();
                }

                _repository.User.DeleteUser(user);
                _repository.Save();

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside DeleteUser action: {ex.InnerException.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

       



    }
}
